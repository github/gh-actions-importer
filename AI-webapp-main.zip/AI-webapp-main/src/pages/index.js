import React from "react";
import Chat from "./lib/Chat";

export default function Home() {
  return <Chat />;
}
